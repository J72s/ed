const { Client, Intents } = require('discord.js-selfbot-v13');
const { getVoiceConnection } = require('@discordjs/voice');
const allowedUsers = require("../allowed.json").allowed;

module.exports = {
    names: {
        list: ["lv"]
    },
    execute(client, message, args) {
        try {
            if (!allowedUsers.includes(message.author.id)) {
                message.channel.send("You don't have permission to use this command.");
                return;
            }

            const voiceConnection = getVoiceConnection(message.guild.id);

            if (!voiceConnection) {
                message.channel.send("I'm not currently in a voice channel.");
                return;
            }

            voiceConnection.destroy();
            message.channel.send("Disconnected from the voice channel.");

        } catch (error) {
            console.error("Error occurred during the event:", error);
            message.channel.send("An error occurred while trying to disconnect from the voice channel.");
        }
    }
};
