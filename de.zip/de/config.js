module.exports = { // Default token, can be omitted if using tokens.json
  logChannelId: '1254157488962404423', // Replace with your desired log channel ID
};