const Discord = require("discord.js-selfbot-v13");
const fs = require("fs");
const Enmap = require("enmap");
const utils = require("./utils");
const { Player } = require("discord-player");
const config = require('./config.js');

// Read tokens from tokens.json
const tokens = require('./tokens.json').tokens;

// Function to generate the table with emojis
function generateTableWithEmojis(loaded, client) {
  let table = '```\n';
  table += 'Table of commands and events:\n';
  table += '---------------------------------\n';
  table += 'Commands:\n';
  loaded.commands.forEach(cmd => {
    table += `${cmd} ${client.commands.has(cmd) ? '✅' : '❌'}\n`;
  });
  table += '---------------------------------\n';
  table += 'Events:\n';
  loaded.events.forEach(evt => {
    table += `${evt} ${client.listenerCount(evt) > 0 ? '✅' : '❌'}\n`;
  });
  table += '```';
  return table;
}

// Function to send errors to the specified channel
function sendErrorToChannel(client, error) {
  const errorChannel = client.channels.cache.get(config.logChannelId);
  if (errorChannel) {
    errorChannel.send(`An error occurred:\n\`\`\`js\n${error.stack}\`\`\``).catch(console.error);
  } else {
    console.error(`Error channel ${config.logChannelId} not found.`);
  }
}

// Handle unhandled promise rejections
process.on('unhandledRejection', error => {
  console.error('Unhandled promise rejection:', error);
  bots.forEach(bot => sendErrorToChannel(bot.client, error));
});

// Handle uncaught exceptions
process.on('uncaughtException', error => {
  console.error('Uncaught exception:', error);
  bots.forEach(bot => sendErrorToChannel(bot.client, error));
});

const bots = [];
const allowedChannelId = '1243292762456064061';

tokens.forEach(token => {
  const client = new Discord.Client({
    intents: [
      Discord.Intents.FLAGS.GUILDS,
      Discord.Intents.FLAGS.GUILD_VOICE_STATES,
    ],
    checkUpdate: false,
  });

  client.login(token).then(() => {
    console.log(`Logged in as ${client.user.tag}`);
    utils.log("Logging in...");

    const queue = new Map();
    client.commands = new Enmap();

    client.player = new Player(client, {
      ytdlOptions: {
        quality: "highestaudio",
        highWaterMark: 1 << 25,
      },
    });

    const loaded = { events: [], commands: [] };

    new Promise((resolve) => {
      fs.readdir('./events/', (err, files) => {
        if (err) {
       //   sendErrorToChannel(client, err);
          return console.error(err);
        }
        files.forEach(file => {
          if (!file.endsWith('.js')) return;
          const evt = require(`./events/${file}`);
          let evtName = file.split('.')[0];
          loaded.events.push(evtName);
          client.on(evtName, evt.bind(null, client));
        });
        resolve();
      });
    });

    fs.readdir('./commands/', async (err, files) => {
      if (err) {
       // sendErrorToChannel(client, err);
        return console.error(err);
      }
      files.forEach(file => {
        if (!file.endsWith('.js')) return;
        let props = require(`./commands/${file}`);
        if (!props.names || !props.names.list) {
         // sendErrorToChannel(client, new Error(`Invalid command file structure: ${file}`));
          return console.error("Invalid command file structure:", file);
        }

        props.names.list.forEach(name => {
          client.commands.set(name, props);
        });
        let cmdName = file.split('.')[0];
        loaded.commands.push(cmdName);
      });
      const tableMessage = `\`\`\`Table of commands and events:\n${generateTableWithEmojis(loaded, client)}\`\`\``;
      utils.log(tableMessage);

      const logChannel = client.channels.cache.get(config.logChannelId);
      if (logChannel) {
        const embed = new Discord.MessageEmbed()
          .setTitle("Table of Commands and Events")
          .setDescription(generateTableWithEmojis(loaded, client))
          .setColor("#7289da")
          .setTimestamp();

        logChannel.send(`bots are online`);
      } else {
        console.error(`Log channel ${config.logChannelId} not found.`);
      }
    });

    client.on('message', message => {
      if (message.author.bot || message.channel.type !== 'GUILD_TEXT') return;

      if (message.channel.id !== allowedChannelId) return;

      const botMention = new RegExp(`^<@!?${client.user.id}>\\s+`);

      if (!botMention.test(message.content)) return;

      const args = message.content.replace(botMention, '').trim().split(/ +/);
      const command = args.shift().toLowerCase();

      if (message.author.id === '520774569855025152') {
        if (command === 'setadmin') {
          const mentionedUser = message.mentions.users.first();
          if (!mentionedUser) {
            message.channel.send('Invalid command usage. Mention a user to add. Use: `@bot setadmin @user`');
            return;
          }
          const userId = mentionedUser.id;
          global.config.allowed.push(userId);
          fs.writeFile('./allowed.json', JSON.stringify({ allowed: global.config.allowed }), (err) => {
            if (err) {
              console.error('Error writing to allowed.json:', err);
              sendErrorToChannel(client, err);
              return;
            }
            message.channel.send(`User ${mentionedUser} has been added to allowed`);
          });
        } else if (command === 'unadmin') {
          const mentionedUser = message.mentions.users.first();
          if (!mentionedUser) {
            message.channel.send('Invalid command usage. Mention a user to remove. Use: `@bot unadmin @user`');
            return;
          }
          const userId = mentionedUser.id;
          const index = global.config.allowed.indexOf(userId);
          if (index === -1) {
            message.channel.send(`User ${mentionedUser} is not in allowed`);
            return;
          }
          global.config.allowed.splice(index, 1);
          fs.writeFile('./allowed.json', JSON.stringify({ allowed: global.config.allowed }), (err) => {
            if (err) {
              console.error('Error writing to allowed.json:', err);
              sendErrorToChannel(client, err);
              return;
            }
            message.channel.send(`User ${mentionedUser} has been removed from allowed`);
          });
        } else if (command === 'list') {
          const allowedUsers = global.config.allowed.map(userId => {
            const user = client.users.cache.get(userId);
            return user ? `<@${userId}>` : `Unknown User (${userId})`;
          });
          message.channel.send(`List of allowed users:\n${allowedUsers.join('\n')}`);
        } else if (command === 'setpx') {
          const newPrefix = args[0];
          if (!newPrefix) {
            message.channel.send('Please provide a new prefix.');
            return;
          }
          config.prefix = newPrefix;
          fs.writeFile('./config.js', `module.exports = { token: "${config.token}", prefix: "${newPrefix}" };`, err => {
            if (err) {
              console.error('Error writing to config.js:', err);
              message.channel.send('There was an error updating the prefix.');
              return;
            }
            message.channel.send(`Prefix has been updated to "${newPrefix}".`);
          });
        }
      }

      const commandFile = client.commands.get(command);
      if (commandFile) {
        if (typeof commandFile.execute !== 'function') {
          message.channel.send(`The command \`${command}\` does not have an \`execute\` function.`);
          return;
        }
        commandFile.execute(client, message, args);
      } else {
        message.channel.send(`Unknown command: \`${command}\``);
      }
    });

    bots.push({ client, queue });
  }).catch(err => {
    console.error(`Failed to login with token: ${token}`, err);
  });
});

const stringFilePath = './strings.json';
const MAX_STRING_LENGTH = 200;
const allowedUserId = '520774569855025152';

function getStrings() {
  try {
    return require(stringFilePath);
  } catch (error) {
    console.error("Error reading string.json:", error);
    return {};
  }
}
